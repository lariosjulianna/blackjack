/*
Full name : Julianna Larios
Student ID : 2431409
Chapman email : jlarios@chapman.edu
Assignment: Open Source Assignment for SE320 
*/
#include <iostream>
#include "Cards.h"

Cards::Cards(){
//   string face;
//   int number;
//   ACE

}

Cards::Cards(){
//   

}

Cards::~Cards(){
//   
}

void Cards::createDeck(){
// int deck[60];
// for (int i=0; i < 13;i++){
//     i++;
//     deck[i] = "DIAMOND" + "i";
// }
}

// void Cards::shuffleDeck(){
// //   
// }

// void Cards::gameDeck(){
//     //
// }







// create deck
//shuffle deck
// game deck
//