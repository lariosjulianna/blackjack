/*
Full name : Julianna Larios
Student ID : 2431409
Chapman email : jlarios@chapman.edu
Assignment: Open Source Assignment for SE320
*/

#ifndef Player_H
#define Player_H


#include <iostream>


class Player{
public: 

// functions public
  
private:
  // private functionns
};

#endif

//17 18 19, models, firts 3 chapters
//predictive, iterative, agile
// knowing what the models are, pros and cons, where would you use it, how di they differ
// spiral vs waterfall
// read the text, look at information, how to think about them conceptually
// difference between models if they are going to deliver a feature
// process models, phases, structure -- how they organize them in differrnt flows
// not gonna cover clean room, dadsm
// how would you recommend a team structure and deliver demos, customer feeedback and such
// free response, no diagrams yet, diagram phases of a model, diagram of deliverables