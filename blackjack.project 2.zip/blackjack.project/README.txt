
1)
# Full name : Julianna Larios
# Student ID : 2431409
# Chapman email : jlarios@chapman.edu
# Open Source Assignment -- SE320

2) File Sources:
- main.cpp
- README.txt
- //

3) Limitations:


4) a. References:


5)Instructions for running the assignment:
Command Line (for Mac):
g++ *.cpp -o b.exe
./b.exe input.txt