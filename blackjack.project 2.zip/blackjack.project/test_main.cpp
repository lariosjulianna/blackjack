/*
Full name : Julianna Larios
Student ID : 2431409
Chapman email : jlarios@chapman.edu
Assignment: Open Source Assignment for SE320 
*/
#include <gtest/gtest.h>


#include "Simulation.h"

TEST(SimulationTest, GameStartsWhenPlayerKnowsHowToPlay) {
    Simulation simulation;
    simulation.startGame();
    EXPECT_TRUE(simulation.gameInPlay());
}

TEST(SimulationTest, GameStartsWhenPlayerNeedsInstructionsAndAgrees) {
    Simulation simulation;

    simulation.startGame();
    EXPECT_TRUE(simulation.gameInPlay());
}

// chatgpt helped with test