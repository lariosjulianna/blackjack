/*
Full name : Julianna Larios
Student ID : 2431409
Chapman email : jlarios@chapman.edu
Assignment: Open Source Assignment for SE320
*/

#ifndef Cards_H
#define Cards_H


#include <iostream>


class Cards{
public: 
enum Rank
    // {
    //     // online
    //     ACE = 1,
    //     TWO = 2,
    //     THREE = 3,
    //     FOUR = 4,
    //     FIVE = 5,
    //     SIX = 6,
    //     SEVEN = 7,
    //     EIGHT = 8,
    //     NINE = 9,
    //     TEN = 10,
    //     JACK = 11,
    //     QUEEN = 12,
    //     KING = 13
    // };
    // enum Suite
    // {
    //     SPADE = 0,
    //     HEART,
    //     CLUB,
    //     DIAMOND
    // };
    // online

// functions public
void createDeck();
  
private:
  // private functionns
};

#endif
