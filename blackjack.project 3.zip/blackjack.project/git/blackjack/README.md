# Black Jack
Classic black jack!

# Setup
Download zip file, make sure you are in the folder,
run g++ main.cpp -o ./b.exe
./b.exe

* Only running the main for now as I still need to fix functionality in other cpp and h files
* Will only compile the main because other files aren't finished

# Rules
* Game starts, Dealer distributes 2 cards to themself and Player
* Dealer's first card is face up, all others are face down
* Calculate your value of cards, if it is below 21 you can hit (another card) or hold (remain with two)
* Goal is to get 21 exactly, or to atleast have avalue higher than the Dealer
* Values cannot be over 21, or you automatically lose
* If Dealer and Player have the same value, it's a tie
    
