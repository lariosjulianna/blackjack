/*
Full name : Julianna Larios
Student ID : 2431409
Chapman email : jlarios@chapman.edu
Assignment: Open Source Assignment for SE320 
*/
#include <iostream>
#include "Simulation.h"


Simulation::Simulation(){
  std::string name = "";
  // m_conn = NULL;
}

Simulation::~Simulation(){
// 
}

// void Simulation::dealFirstCards(){
// //  
// }

// void Deal::dealHit(){
// //   
// }

bool gameInPlay;

// ? Function that starts the game/changes the boolean/gives instructions/triggers the card dealing
void Simulation::startGame(){
std::string instructions_input;
std::string final_input;

std::cout << "Dealer: Welcome to Black Jack, do you know how to play?" << std::endl;
std::cout << "Press 1 if you do, 0 if you need instructions." << std::endl;
std::cin >> instructions_input;


if (instructions_input == "1"){
    // deal cards function
     gameInPlay = true;
} else if (instructions_input == "0"){
    gameInPlay = false;
    std::cout << "Players play against the Dealer. Both will begin with two random cards, the Dealer's first card will be face up. After you look at your two cards, you decide if you want to hit (get another card), or hold (keep your current hand). The goal is to get exactly 21, or a higher number than the dealer -- but you can't go OVER 21, or you lose." << std::endl;
    std::cout << "Ready to play? Press 1 to start." << std::endl;
    std::cin >> final_input;
    if (final_input == "1"){
        // deal cards function
        gameInPlay = true;
    } 
}
}

// ? Bool function to see if the game is in play or not
bool Simulation::isGameInPlay(){
//   return (m_adj[i][j] < std::numeric_limits<double>::max());
return gameInPlay;
}

// if(gameInPlay == true){
    
// }


