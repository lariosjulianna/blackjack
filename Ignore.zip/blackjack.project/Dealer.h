/*
Full name : Julianna Larios
Student ID : 2431409
Chapman email : jlarios@chapman.edu
Assignment: Open Source Assignment for SE320
*/

#ifndef Dealer_H
#define Dealer_H


#include <iostream>


class Dealer{
public: 

// functions public
  
private:
  // private functionns
};

#endif