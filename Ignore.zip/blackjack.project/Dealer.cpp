/*
Full name : Julianna Larios
Student ID : 2431409
Chapman email : jlarios@chapman.edu
Assignment: Open Source Assignment for SE320 
*/

#include "Dealer.h"

Dealer::Dealer(){
  // name = "";
  // m_adj = NULL;
  // m_conn = NULL;
}

Dealer::Dealer(){
//   

}

Dealer::~Dealer(){
//   
}

void Dealer::dealFirstCards(){
//   
}

void Deal::dealHit(){
//   
}

voidl Dealer::revealCards(){
//  
}


