/*
Full name : Julianna Larios
Student ID : 2431409
Chapman email : jlarios@chapman.edu
Assignment: Open Source Assignment for SE320
*/

#ifndef Simulation_H
#define Simulations_H


#include <iostream>


class Simulation{
public: 

// functions public
  
private:
  // private functionns
};

#endif