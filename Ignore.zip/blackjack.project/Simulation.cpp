/*
Full name : Julianna Larios
Student ID : 2431409
Chapman email : jlarios@chapman.edu
Assignment: Open Source Assignment for SE320 
*/

#include "Simulation.h"

Simulation::Simulation(){
  // name = "";
  bool gameInPlay = false;
  // m_conn = NULL;
}

Simulation::Simulation(){
//   

}

Simulation::~Simulation(){
// 
}

void Dealer::dealFirstCards(){
//  
}

void Deal::dealHit(){
//   
}

// ? Function that starts the game/changes the boolean/gives instructions/triggers the card dealing
void Simulation::startGame(){
string instructions_input;
string final_input;

cout << "Dealer: Welcome to Black Jack, do you know how to play?" << endl;
cout << "Press 1 if you do, 0 if you need instructions." << endl;
cin >> instructions_input;
if (instructions_input == "1"){
    // deal cards function
     gameInPlay =true;
} else if (instructions_input == "0"){
    gameInPlay = false;
    cout << "Players play against the Dealer. Both will begin with two random cards, the Dealer's first card will be face up. After you look at your two cards, you decide if you want to hit (get another card), or hold (keep your current hand). The goal is to get exactly 21, or a higher number than the dealer -- but you can't go OVER 21, or you lose." << endl;
    cout << "Ready to play? Press 1 to start." << endl;
    cin >> final_input;
    if (final_input == "1"){
        // deal cards function
        gameInPlay = true;
    } 
}
}

// ? Bool function to see if the game is in play or not
bool Simulation::gameInPlay(){
//   return (m_adj[i][j] < std::numeric_limits<double>::max());
return gameInPlay;
}



